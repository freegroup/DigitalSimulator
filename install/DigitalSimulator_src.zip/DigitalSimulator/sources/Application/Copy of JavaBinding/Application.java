import java.util.*;

/**
 *  Description of the Class
 *
 *@author     c5026971
 *@created    2. Oktober 2001
 */
public class Application
{
    /**
     *  Description of the Method
     */
    public static void onInit()
    {
        Trace.info("Application.onInit() called");
    }


    /**
     *  Description of the Method
     */
    public static void onExit()
    {
        Trace.info("Application.onExit() called");
    }


    /**
     *  Description of the Method
     *
     *@param  xmlData  Description of Parameter
     */
    public static void onExport(String xmlData)
    {

        Trace.info("Application.onExport(DigitalObject[] objects) called");
        Trace.info(xmlData);
    }
}
