import java.util.*;

public class Painter
{
   public static native void drawLine(int x1, int y1, int x2, int y2);
   public static native void drawOval(int x1, int y1, int width, int height);
   public static native void drawRect(int x1, int y1, int x2, int y2);
   public static native void drawText(String str , int fontHeight, int left, int top);
}

