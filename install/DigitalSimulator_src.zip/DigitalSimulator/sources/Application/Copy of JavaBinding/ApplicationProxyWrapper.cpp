#include "stdafx.h"

#include "Application\Objects\plugin\java\JavaPluginManager.h"

#include "ApplicationProxyWrapper.h"

using namespace de::freegroup::jnipp;

//----------------------------------------------------------------------------
void ApplicationProxyWrapper::onInit()
//----------------------------------------------------------------------------
{
   if(JavaPluginManager::isOk())
      ApplicationProxy::onInit();
}

//----------------------------------------------------------------------------
void ApplicationProxyWrapper::onExit()
//----------------------------------------------------------------------------
{
   if(JavaPluginManager::isOk())
      ApplicationProxy::onExit();
}

//----------------------------------------------------------------------------
void ApplicationProxyWrapper::onExport(JStringHelper& p0)
//----------------------------------------------------------------------------
{
   if(JavaPluginManager::isOk())
      ApplicationProxy::onExport(p0);
}

