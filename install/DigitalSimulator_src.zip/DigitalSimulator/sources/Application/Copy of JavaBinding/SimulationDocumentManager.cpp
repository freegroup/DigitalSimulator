// SimulationDocumentManager.cpp: implementation of the SimulationDocumentManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimulationDocumentManager.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SimulationDocumentManager::SimulationDocumentManager()
{

}

SimulationDocumentManager::~SimulationDocumentManager()
{

}

jint SimulationDocumentManager::getDocumentWidth(JNIEnv *,  jobject)
{
   return 0;
}

jint SimulationDocumentManager::getDocumentHeight(JNIEnv *, jobject)
{
   return 0;
}
