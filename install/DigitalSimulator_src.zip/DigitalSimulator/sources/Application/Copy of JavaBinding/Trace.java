import java.util.*;

public class Trace
{
   public static native void error(String message);
   public static native void warning(String message);
   public static native void info(String message);
}

