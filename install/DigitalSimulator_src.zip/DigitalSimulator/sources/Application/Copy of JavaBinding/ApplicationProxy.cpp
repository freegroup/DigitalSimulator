#include "JNIEnvHelper.h"

#include "ApplicationProxy.h"

using namespace de::freegroup::jnipp;


std::string ApplicationProxy::className = "Application";
jclass ApplicationProxy::objectClass = NULL;

jclass ApplicationProxy::_getObjectClass()
{
	if ( objectClass == NULL )
		objectClass = static_cast<jclass>( JNIEnvHelper::NewGlobalRef( JNIEnvHelper::FindClass( className.c_str() ) ) );

	return objectClass;
}

jclass ApplicationProxy::getObjectClass()
{
	return _getObjectClass();
}

ApplicationProxy::operator jobject()
{
	return peerObject;
}

// constructors
ApplicationProxy::ApplicationProxy(jobject obj)
{
	peerObject = JNIEnvHelper::NewGlobalRef( obj );
}

ApplicationProxy::ApplicationProxy()
{
	JNIStack jniStack;
	jmethodID mid = JNIEnvHelper::GetMethodID( getObjectClass(), "<init>", "()V" );
	peerObject = JNIEnvHelper::NewGlobalRef( JNIEnvHelper::NewObject( getObjectClass(), mid ) );
}

// attribute getters
// attribute setters
// methods
void ApplicationProxy::onInit()
{
	JNIStack jniStack;
	jmethodID mid = JNIEnvHelper::GetStaticMethodID( _getObjectClass(), "onInit", "()V" );
	JNIEnvHelper::CallStaticVoidMethod( _getObjectClass(), mid );
}

void ApplicationProxy::onExit()
{
	JNIStack jniStack;
	jmethodID mid = JNIEnvHelper::GetStaticMethodID( _getObjectClass(), "onExit", "()V" );
	JNIEnvHelper::CallStaticVoidMethod( _getObjectClass(), mid );
}

void ApplicationProxy::onExport(JStringHelper& p0)
{
	JNIStack jniStack;
	jmethodID mid = JNIEnvHelper::GetStaticMethodID( _getObjectClass(), "onExport", "(Ljava/lang/String;)V" );
	JNIEnvHelper::CallStaticVoidMethod( _getObjectClass(), mid, static_cast<jobject>( p0 ) );
}

