import java.util.*;
import java.io.*;
import java.net.*;
import org.w3c.dom.Document;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.xml.sax.*;
import de.freegroup.digitalsimulator.dialogs.MsgBox;
import de.freegroup.digitalsimulator.plugin.PluginManager;
import de.freegroup.util.file.Directory;
import ObjectPlugin;

/**
 *  Description of the Class
 *
 *@author     c5026971
 *@created    2. Oktober 2001
 */
public class Application
{
    /**
     *  Description of the Method
     */
    public static void onInit()
    {
        Trace.info("Loading java object extensions");
        Trace.info("------------------------------");
        try
        {
            String pluginDir = Configuration.getString(Configuration.PLUGIN_PATH);

            ArrayList files = Directory.getAll(new File(pluginDir),false);
            Iterator iter = files.iterator();
            while(iter.hasNext())
            {
                File file = (File)iter.next();
                String className=null;

                // get the class name of the file
                //
                if(file.getName().endsWith(".class"))
                {
                    className = file.getName().substring(0,file.getName().length()-6);
                }
                // get the class name from the manifest entry
                //
                else if(file.getName().endsWith(".jar"))
                {
                    try
                    {
                        java.util.jar.JarFile jarfile = new java.util.jar.JarFile(file);
                        className = jarfile.getManifest().getMainAttributes().getValue("Main-Class");
                    }
                    catch (Exception ex)
                    {
                        Trace.warning("Exception during read of jar file",ex);
                    }
                }
                else
                {
                    // ignore the class or package
                    className = null;
                }

                // check if the class inherited from ObjectPlugin and register
                // this class in the DigitalSimulator
                //
                if(className!=null)
                {
                    Object obj = Class.forName(className).newInstance();
                    if(obj instanceof ObjectPlugin)
                    {
                        // map the de.freegroup.plugins.... class name to the JNI required
                        // notation 'de/freegroup/plugins...'
                        //
                        PluginManager.registerPlugin(className.replace('.','/'));
                        ((ObjectPlugin)obj).init();
                    }
                }
            }
        }
        catch(Exception exc)
        {
            Trace.error("Unable to load all object plugins",exc);
        }
    }


    /**
     *  Description of the Method
     */
    public static void onExit()
    {
        Trace.info("Application.onExit() called");
    }

    /**
     *
     */
    public static void onUpdatePlugins()
    {
        Trace.info("Application.onUpdatePlugins() called");
        try
        {
            // The Thread is for the second event loop.
            // Is there no Thread the main GUI from the DigitalSimulator
            // will not receive any paint requests.
            //
            Thread thread = new Thread ( new Runnable ( )
            {
                public void run ( )
                {
                    PluginManager.download();
                }
            });
            thread.setDaemon(true);
            thread.start();
        }
        catch (Exception ex)
        {
            Trace.error("Unable to create Dialog Thread",ex);
        }
    }

    /**
     *  Description of the Method
     *
     *@param  xmlData  Description of Parameter
     */
    public static void onExport(String xmlData)
    {
        Trace.info("Application.onExport(DigitalObject[] objects) called");
        Trace.info(xmlData);
    }
}
