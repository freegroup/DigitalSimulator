/**
 * Title:        JavaBridge for the DigitalSimulator
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      FreeGroup
 * @author Andreas Herz
 * @version 1.0
 */

public class Configuration
{
    public static final String WMF_PATH         = "WMFPath";
    public static final String BMP_PATH         = "BMPPath";
    public static final String PALETTE_PATH     = "PalettePath";
    public static final String PLUGIN_PATH      = "PluginPath";
    public static final String BASIC_PATH       = "BasicPath";
    public static final String SCRIPT_PATH      = "ScriptPath";
    public static final String LANGUAGE_PATH    = "LanguagePath";
    public static final String APPLICATION_PATH = "ApplicationPath";
    public static final String LOGGING_PATH     = "LoggingPath";

   public static native String getString(String key);
   public static native void   setString(String key, String value);
}