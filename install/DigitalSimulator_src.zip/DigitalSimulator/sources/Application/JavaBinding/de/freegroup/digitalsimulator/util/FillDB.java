package de.freegroup.digitalsimulator.util;

/**
 * Title:        JavaBridge for the DigitalSimulator
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      FreeGroup
 * @author Andreas Herz
 * @version 1.0
 */
import de.freegroup.digitalsimulator.export.wired.db.*;

public class FillDB
{

    public static void main(String[] args)
    {
        Object2Case.destroyAll();
        ElectricObject.destroyAll();
        ObjectLayout.destroyAll();
        ObjectPin.destroyAll();
        CasePin.destroyAll();
        CaseLayout.destroyAll();
        ElectricCase.destroyAll();
        CaseDependency.destroyAll();
        DependencyPin.destroyAll();

        // create a NAND and all related dependencies
        //

        // generate the Caselayout
        //
        CaseLayout    cl = CaseLayout.createInstance();
        CasePin     cp01 = CasePin.createInstance(0,1,cl,0);
        CasePin     cp02 = CasePin.createInstance(0,2,cl,0);
        CasePin     cp03 = CasePin.createInstance(0,3,cl,0);
        CasePin     cp04 = CasePin.createInstance(0,4,cl,0);
        CasePin     cp05 = CasePin.createInstance(0,5,cl,0);
        CasePin     cp06 = CasePin.createInstance(0,6,cl,0);

        // generate the internal object layout
        //
        ObjectLayout   ol = ObjectLayout.createInstance();
        ObjectPin      op01 = ObjectPin.createInstance(ol,1,cp02);
        ObjectPin      op02 = ObjectPin.createInstance(ol,2,cp03);
        ObjectPin      op03 = ObjectPin.createInstance(ol,3,cp06);

        // generate the object and the case
        //
        ElectricObject eobj = ElectricObject.createInstance(false,ol,"NAND_OBJ");
        ElectricCase   c    = ElectricCase.createInstance("7400",cl);
        Object2Case    o2c  = Object2Case.createInstance(c, eobj);
    }
}