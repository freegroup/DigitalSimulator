package de.freegroup.digitalsimulator.db;
/**
 * Title:        short-i
 * Description:  Information retrival System with human language interface
 * Copyright:    Copyright (c) 2001
 * Company:      short-i
 * @author David Sommer & Andreas Herz
 * @version 1.0
 */
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import Trace;
import Configuration;

public class ConnectionManager
{

   private static String  m_user;
   private static String  m_password;
   private static String  m_database;
   private static String  m_driver;
   private static ArrayList  m_connections;

   /**
    * Init the Database with the hands over JDBC driver and the database, user, password.
    *
    */
   public static void init(String jdbcDriver,  String database, String user, String password )
   {
      // Find and load the JDBC driver in the DriverManager
      // Safeguard operations
      try
      {
         //
         Trace.info("--------------------------------------");
         Trace.info("initialize the ConnectionManager");
         Trace.info("--------------------------------------");
         Trace.info("   open connection to");
         Trace.info("   driver     :["+jdbcDriver+"]");
         Trace.info("   database   :["+database+"]");
         Trace.info("   user       :["+user+"]");
         Trace.info("   password   :["+password+"]");
         Class.forName ( jdbcDriver ).newInstance();
         m_driver      = jdbcDriver;
         m_database    = database;
         m_user        = user;
         m_password    = password;
         m_connections = new ArrayList();
         m_connections.add(0,new SaveConnection(DriverManager.getConnection( database, user , password )));
         Trace.info("--------------------------------------\n");
      }
      catch ( Exception exc )
      {
         Trace.error("unable to open db-connection", exc );
      }
   }

   /**
   * Return a valid JDBC connection.
   */
   public static synchronized SaveConnection getValid()
   {
      // Safeguard operations
      try
      {
         // pr�fen ob connection noch g�lig ist
         //
         if(m_connections==null)
         {
            // object not initialized.....try to get the params from the config object
            // and read the jdbc informations
//            String driver   = Configuration.getString("jdbc.driver");
//            String database = Configuration.getString("jdbc.database");
//            String user     = Configuration.getString("jdbc.user");
//            String password = Configuration.getString("jdbc.password");
            String driver          = "sun.jdbc.odbc.JdbcOdbcDriver";
            String database        = "jdbc:odbc:dsim";
            String user            = "dsim";
            String password        = "dsim";

            init(driver,database,user,password );
            return getValid();
         }
         else
         {
            SaveConnection con = (SaveConnection)m_connections.get(0);
            if(con.isClosed())
            {
               m_connections.add(0, new SaveConnection(DriverManager.getConnection( m_database, m_user , m_password )));
            }
         }
      }
      catch ( Exception exc )
      {
         Trace.error("unable to read and open db",exc);
      }
      // return a valid connection
      //
      return (SaveConnection)m_connections.get(0);
   }
}