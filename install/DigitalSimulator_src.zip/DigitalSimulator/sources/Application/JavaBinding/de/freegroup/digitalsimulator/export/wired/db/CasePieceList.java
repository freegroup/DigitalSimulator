package de.freegroup.digitalsimulator.export.wired.db;

/**
 * Title:        JavaBridge for the DigitalSimulator
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      FreeGroup
 * @author Andreas Herz
 * @version 1.0
 */
import java.util.ArrayList;
import java.util.List;

public class CasePieceList
{
    List cases = new ArrayList();

}
