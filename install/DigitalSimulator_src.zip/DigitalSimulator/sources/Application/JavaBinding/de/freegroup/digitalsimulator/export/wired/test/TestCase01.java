package de.freegroup.digitalsimulator.export.wired.test;

/**
 * Title:        JavaBridge for the DigitalSimulator
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      FreeGroup
 * @author Andreas Herz
 * @version 1.0
 */
import de.freegroup.digitalsimulator.export.wired.db.*;
import java.util.ArrayList;
import java.util.Iterator;

public class TestCase01
{
    public static void main(String[] args)
    {
        // we have 2 objects
        // 2 AND
        //                       +-----+
        //                     1 |     |
        //    -------------------+     |
        //         +-----+       |  &  +----
        //       1 |     |     2 |     | 3
        //    -----+     |   +---+     |
        //         |  &  +---+   +-----+
        //       2 |     |3      object2
        //    -----+     |
        //         +-----+
        //         object1
        //

        // beide eventuel verschieden object finden
        //
        ElectricObject object1 = ElectricObject.findByType("NAND_OBJ");
        ElectricObject object2 = ElectricObject.findByType("NAND_OBJ");

        ObjectPin opin1= object1.getPin(3);
        ObjectPin opin2= object2.getPin(3);

        System.out.println("Geh�use 1 pin "+opin1.getCasePin().getNumber()+" --> Geh�use 2 pin "+opin2.getCasePin().getNumber());
    }
}