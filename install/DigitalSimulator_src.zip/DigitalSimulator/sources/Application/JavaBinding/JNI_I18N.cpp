#include "stdafx.h"
#include "JNI_I18N.h"
#include "Application\i18n\ResourceTranslater.h"
#include "Application\Debug\LogManager.h"

/*
 * Class:     I18N
 * Method:    translate
 * Signature: (Ljava/lang/String;)Ljava/lang/String
 */
jstring JNICALL Java_I18N_translate(JNIEnv *env, jclass, jstring jobj)
{
	PROC_TRACE;

	const char *key = env->GetStringUTFChars( (jstring)jobj, 0);

   CString value = TRANSLATE(key);
	env->ReleaseStringUTFChars( (jstring)jobj, key);

   return env->NewStringUTF((LPCSTR)value);
}

