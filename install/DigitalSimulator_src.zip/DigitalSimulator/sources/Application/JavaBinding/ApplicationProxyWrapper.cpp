#include "stdafx.h"

#include "Application\Objects\plugin\java\JavaPluginManager.h"

#include "ApplicationProxyWrapper.h"

using namespace de::freegroup::jnipp;

//----------------------------------------------------------------------------
void ApplicationProxyWrapper::onInit()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   if(JavaPluginManager::isOk())
      ApplicationProxy::onInit();
}

//----------------------------------------------------------------------------
void ApplicationProxyWrapper::onExit()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   if(JavaPluginManager::isOk())
      ApplicationProxy::onExit();
}


//----------------------------------------------------------------------------
void ApplicationProxyWrapper::onUpdatePlugins()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   if(JavaPluginManager::isOk())
      ApplicationProxy::onUpdatePlugins();
}

//----------------------------------------------------------------------------
void ApplicationProxyWrapper::onExport(JStringHelper& p0)
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   if(JavaPluginManager::isOk())
      ApplicationProxy::onExport(p0);
}

//----------------------------------------------------------------------------
void ApplicationProxyWrapper::setProxy(JStringHelper& proxy, jint port)
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   if(JavaPluginManager::isOk())
      ApplicationProxy::setProxy(proxy,port);
}
