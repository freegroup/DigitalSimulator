import java.util.*;
import java.io.*;

public class Trace
{
//   public static native void error(String message);
//   public static native void warning(String message);
//   public static native void info(String message);
   public static void error(String message)
   {
    System.out.println(message);
   }

   public static void warning(String message)
   {
    System.out.println(message);
   }

   public static void info(String message)
   {
    System.out.println(message);
   }

   public static void error(String message, Throwable exc)
   {
      error(message +"\n"+excMessage(exc));
   }

   public static void warning(String message, Throwable exc)
   {
      warning(message +"\n"+excMessage(exc));
   }

   public static void info(String message, Throwable exc)
   {
      info(message +"\n"+excMessage(exc));
   }

   public static void error( Throwable exc)
   {
      error(excMessage(exc));
   }

   public static void warning(Throwable exc)
   {
      warning(excMessage(exc));
   }

   public static void info( Throwable exc)
   {
      info(excMessage(exc));
   }

   private static String excMessage(Throwable exc)
   {
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);

      exc.printStackTrace(pw);
      return sw.toString();
   }
}

