// SimulationDocumentManager.cpp: implementation of the SimulationDocumentManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimulationDocumentManager.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SimulationDocumentManager::SimulationDocumentManager()
{
	PROC_TRACE;


}

SimulationDocumentManager::~SimulationDocumentManager()
{
	PROC_TRACE;


}

jint SimulationDocumentManager::getDocumentWidth(JNIEnv *,  jobject)
{
	PROC_TRACE;

   return 0;
}

jint SimulationDocumentManager::getDocumentHeight(JNIEnv *, jobject)
{
	PROC_TRACE;

   return 0;
}
