#include "stdafx.h"
#include "JNI_ObjectPlugin.h"
#include "Application\Configuration\ParameterManager.h"
#include "Application\Debug\LogManager.h"
#include "Application\Objects\buildin\Digital\ElectricNodeContext.h"

static CElectricNode::CElectricNodeDokument* currentObjectData=NULL;

void setCurrentObjectData(CElectricNode::CElectricNodeDokument* _data)
{
	PROC_TRACE;

   currentObjectData = _data;
}

/*
 * Class:     ObjectPlugin
 * Method:    invertInput
 * Signature: (IZ)V
 */
void  JNICALL Java_ObjectPlugin_invertInput(JNIEnv *, jobject jobj, jint index, jboolean inverted)
{
	PROC_TRACE;

   if(currentObjectData!=NULL)
   {
      if((index<currentObjectData->inCount)&& (index>=0))
         currentObjectData->inPorts[index]->SetInverter(inverted==JNI_TRUE?true:false);
      else
         LogManager::log(LogManager::error ,"out of index in method 'Java_ObjectPlugin_invertInput' Action will be ingnored.");
   }
}

/*
 * Class:     ObjectPlugin
 * Method:    invertOutput
 * Signature: (IZ)V
 */
void  JNICALL Java_ObjectPlugin_invertOutput(JNIEnv *, jobject jobj, jint index, jboolean inverted)
{
	PROC_TRACE;

   LogManager::log(LogManager::debug1 ,"invertOutput called");
   if(currentObjectData!=NULL)
   {
      if((index<currentObjectData->outCount)&& (index>=0))
         currentObjectData->outPorts[index]->SetInverter(inverted==JNI_TRUE?true:false);
      else
         LogManager::log(LogManager::error ,"out of index in method 'Java_ObjectPlugin_invertOutput' Action will be ingnored.");
   }
}

