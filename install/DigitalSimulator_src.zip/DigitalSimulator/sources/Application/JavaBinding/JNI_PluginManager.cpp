#include "stdafx.h"
#include "JNI_Trace.h"
#include "Application\Objects\plugin\Java\JavaPluginManager.h"
#include "Application\JavaBinding\JNI_PluginManager.h"
#include "Application\Debug\LogManager.h"


/*
 * Class:     PluginManager
 * Method:    registerPlugin
 * Signature: (Ljava/lang/String;)V
 */
void JNICALL Java_PluginManager_registerPlugin  (JNIEnv *env, jclass, jstring jobj)
{
	PROC_TRACE;

	const char *str = env->GetStringUTFChars( (jstring)jobj, 0);
   JavaPluginManager::registerPlugin((char*)str);
	env->ReleaseStringUTFChars( (jstring)jobj, str);
}
