/* NO WARRANTY
 *
 *    BECAUSE THE PROGRAM IS IN THE PUBLIC DOMAIN, THERE IS NO
 *    WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE
 *    LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE AUTHORS
 *    AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT
 *    WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *    BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 *    AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS TO
 *    THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD
 *    THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL
 *    NECESSARY SERVICING, REPAIR OR CORRECTION.
 *
 *    IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
 *    WRITING WILL ANY AUTHOR, OR ANY OTHER PARTY WHO MAY MODIFY
 *    AND/OR REDISTRIBUTE THE PROGRAM, BE LIABLE TO YOU FOR DAMAGES,
 *    INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL
 *    DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM
 *    (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING
 *    RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES
 *    OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
 *    PROGRAMS), EVEN IF SUCH AUTHOR OR OTHER PARTY HAS BEEN ADVISED
 *    OF THE POSSIBILITY OF SUCH DAMAGES.
 */


#ifndef __LOGFILE__H__
#define __LOGFILE__H__
#pragma warning(disable : 4786)
#include <fstream>
#include "ExtendedTrace.h"

class LogManager
{
public:
   enum LogLevel {
      none   =0,
      error,
      warning,
      info,
      debug1,
      debug2,
      debug3
   };

   LogManager();

   static void	  log(LogManager::LogLevel level ,TCHAR* formatString, ...);	
//   static void   setLevel(bool flag);

   virtual char* const GetClassName(){return "LogManager";};
protected:


private:
//	static bool     s_enableLogging;
	static int      s_spacing;
   static LogLevel s_currentLogLevel;

};

typedef LogManager LM ;


class StackLogObject{
public:
   StackLogObject(const char *  );
   ~StackLogObject();
protected:

   char* m_logMsg;
};

#ifdef _DEBUG
#define PROC_TRACE   StackLogObject stackTraceObject((LPCSTR)FNPARAMTRACE())
#else
#define PROC_TRACE   //static char __FUNCTION__[] = x;                  \
                     //StackLogObject stackTraceObject(__FUNCTION__);   
#endif

#endif	// __LOGFILE__H__