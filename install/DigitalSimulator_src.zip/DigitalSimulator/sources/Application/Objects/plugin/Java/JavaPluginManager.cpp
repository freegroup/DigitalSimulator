#ifdef WITH_JVM


// JavaPluginManager.cpp: Implementierung der Klasse JavaPluginManager.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4786)
#include <vector>
#include <CString>
#include <algorithm>
#include <stdio.h>
#include <io.h>
#include "stdafx.h"

// libryries/JNI
#include "JNIEnvHelper.h"
#include "JVM.h"

#include "Application\Debug\LogManager.h"
#include "Application\Configuration\ParameterManager.h"
#include "Application\Objects\plugin\Java\Context\ElectricNodeContextJavaWrapper.h"

#include "Application\Dialogs\FileFinder\FindFileDlg.h"
#include "Application\Dialogs\FileFinder\FileFinder.h"
#include "Application\Dialogs\JavaPlugin\DialogSelectJVM.h"
#include "Application\JavaBinding\JNI_I18N.h"
#include "Application\JavaBinding\JNI_Painter.h"
#include "Application\JavaBinding\JNI_Trace.h"
#include "Application\JavaBinding\JNI_Configuration.h"
#include "Application\JavaBinding\JNI_PluginManager.h"
#include "Application\JavaBinding\JNI_ObjectPlugin.h"

#include "JavaPluginManager.h"

#ifdef _WIN32
#define PATH_SEPARATOR ';'
#else /* UNIX */
#define PATH_SEPARATOR ':'
#endif

using namespace de::freegroup::jnipp;


JavaPluginManager javaVM;


JNINativeMethod painter_methods[] = 
{
   {"drawLine"  ,"(IIII)V"                 ,Java_Painter_drawLine},
   {"drawOval"  ,"(IIII)V"                 ,Java_Painter_drawOval},
   {"drawRect"  ,"(IIII)V"                 ,Java_Painter_drawRect},
   {"drawText","(Ljava/lang/String;III)V" ,Java_Painter_drawText}
};


JNINativeMethod trace_methods[] = 
{
   {"error",  "(Ljava/lang/String;)V"   ,Java_Trace_error},
   {"warning","(Ljava/lang/String;)V"   ,Java_Trace_warning},
   {"info",   "(Ljava/lang/String;)V"   ,Java_Trace_info}
};


JNINativeMethod configuration_methods[] = 
{
   {"getString",  "(Ljava/lang/String;)Ljava/lang/String;"  ,Java_Configuration_getString},
   {"setString",  "(Ljava/lang/String;Ljava/lang/String;)V" ,Java_Configuration_setString}
};


JNINativeMethod i18n_methods[] = 
{
   {"translate",  "(Ljava/lang/String;)Ljava/lang/String;"   ,Java_I18N_translate}
};


JNINativeMethod plugin_methods[] = 
{
   {"registerPlugin",  "(Ljava/lang/String;)V"   ,Java_PluginManager_registerPlugin}
};

JNINativeMethod objectPlugin_methods[] = 
{
   {"invertInput",   "(IZ)V"   ,Java_ObjectPlugin_invertInput},
   {"invertOutput",  "(IZ)V"   ,Java_ObjectPlugin_invertOutput}
};


jclass  JavaPluginManager::m_i18nClass;
jclass  JavaPluginManager::m_configurationClass;
jclass  JavaPluginManager::m_painterClass;
jclass  JavaPluginManager::m_traceClass;
jclass  JavaPluginManager::m_pluginManagerClass;
jclass  JavaPluginManager::m_objectPluginClass;
bool    JavaPluginManager::m_isOk;

#define _countof(array) (sizeof(array)/sizeof(array[0]))

//----------------------------------------------------------------------------
void JavaPluginManager::init()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   // combine my classpath with system's
   //
   CString  javaPath  = GET_PARAMETER("JavaPluginPath");
   CString  appPath   = GET_PARAMETER("ApplicationPath");
	CString 	classPath = javaPath;
   classPath.TrimRight('\\');
	appPath.TrimRight('\\');

   // setting he class path

   LM::log(LM::info,"add to class path :'%s'",(LPCSTR)classPath);
   JVM::appendClassPath((LPCSTR)classPath);
   LM::log(LM::info,"add to class path :'%s'",(LPCSTR)(appPath+"\\java"));
   JVM::appendClassPath((LPCSTR)(appPath+"\\java"));
   registerJarsInDirectory(javaPath);
   registerJarsInDirectory(appPath +"\\");
   registerJarsInDirectory(appPath +"\\libs\\");
   registerJarsInDirectory(appPath +"\\jars\\");
   registerJarsInDirectory(appPath +"\\java\\");

   m_isOk = false;

   // select and load the JVM
   //
   if(selectJVMLibrary())
   {
      // Native Wrapper laden
      //
      registerI18N();
      registerPainter();
      registerTrace();
      registerConfiguration();
      registerPluginManager();
      registerObjectPlugin();

      m_isOk = true;
   }
}

//----------------------------------------------------------------------------
void JavaPluginManager::registerPlugin(CString className)
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   LM::log(LM::info,"loading object plugin '%s'",(LPCSTR)className);
   new CElectricNodeContextJavaWrapper((char*)(LPCSTR)className);
}

//----------------------------------------------------------------------------
void JavaPluginManager::registerJarsInDirectory(CString directory)
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   struct _finddata_t c_file;
   long hFile;


   // append all jars in the plugin directory to the class path
   //
   if( (hFile = _findfirst( (directory+"*.jar"), &c_file )) == -1L )
   {
      // no jars in this directory
   }
   else 
   {
      LM::log(LM::info,"add to class path :'%s'",(LPCSTR)(directory+c_file.name));
      JVM::appendClassPath((LPCSTR)(directory+c_file.name));
      /* Find the rest of the jars */
      while( _findnext( hFile, &c_file ) == 0 )
      {
         LM::log(LM::info,"add to class path :'%s'",(LPCSTR)(directory+c_file.name));
         JVM::appendClassPath((LPCSTR)(directory+c_file.name));
      }

      _findclose( hFile );
   }
}

//----------------------------------------------------------------------------
bool JavaPluginManager::selectJVMLibrary()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   if(GET_PARAMETER("LoadRegistryJVM").CompareNoCase("true")==0)
   {
      try
      {
         // Load the dedicated JavaVirtualMachine into system
         //
         JVM::load();

         if(JNIEnvHelper::getEnv()==NULL)
         {
            SET_PARAMETER("JavaVirtualMachine","");
            AfxMessageBox("Can't load the selected JavaVirtualMachine. \r\nInstall the \"Java Runtime Enviroment 1.3\" from www.javasoft.com!!",MB_ICONSTOP );
            return false;
         }
      }
      catch(...)
      {
         // error during loading the JVM
         AfxMessageBox("Can't load a JavaVirtualMachine. \r\nInstall the \"Java Runtime Enviroment 1.3\" from www.javasoft.com.\r\n** Java features now disabled **",MB_ICONSTOP );
         return false;
      }
   }
   else
   {
      // check if a virtual machine was loaded before
      //
      CString jvm = GET_PARAMETER("JavaVirtualMachine");
      if(jvm !="")
      {
         // check if the machione already exist
         //
         //mode Value Checks File For 
         //00 Existence only 
         //02  Write permission 
         //04 Read permission 
         //06 Read and write permission 
         if(_access((LPCSTR)jvm,00) == -1)
         {
            // jvm not already valid
            // 
            jvm = "";
         }
      }

      // try to find a valid jvm
      //
      if(jvm=="")
      {
         CFindFileDlg dlg;

         dlg.m_csRootFolder           = "C:\\";    // root folder of search
         dlg.m_csFindFile             = "jvm.dll"; // file to search for
         dlg.m_bRecurse               = true;      // search subfolders
         dlg.m_bFindSingleFile        = false;     // find multiple files
         dlg.m_bSearchNetworkDrives   = false;     // ignore network drives
         dlg.m_bSearchRemovableDrives = false;     // ignore removable drives
         dlg.m_bSearchCDROMDrives     = false;     // ignore CD-ROM drives
         dlg.m_csTitle                = "searching for Java Virtual Machine...";

         // do it. 
         int nResponse = dlg.DoModal();

         // done
         if (nResponse == IDOK)
         {
             CDialogSelectJVM jvmDlg;
          
             int size = dlg.m_csaFoundFiles.GetSize();
             while(size--)
             {
                TRACE("%s\n",(LPCSTR)dlg.m_csaFoundFiles.ElementAt(size));
                jvmDlg.m_jvms.Add((LPCSTR)dlg.m_csaFoundFiles.ElementAt(size));
             }

             if(jvmDlg.DoModal()==IDOK)
             {
                jvm =jvmDlg.m_jvm;
                SET_PARAMETER("JavaVirtualMachine",jvm);
             }
             else
             {
               // it makes no sense, that the DigitalSimulator-JavaExtended works without
               // a valid JVM. Use the the DigitalSimulator-StandartEdition instead!!!
               AfxMessageBox("You must select a JavaVirtualMachine Version 1.3. \r\nInstall the \"Java Runtime Enviroment 1.3\" from www.javasoft.com!!",MB_ICONSTOP );
               return false;
             }

         }
         else if (nResponse == IDCANCEL)
         {
            // it makes no sense, that the DigitalSimulator-JavaExtended works without
            // a valid JVM. Use the the DigitalSimulator-StandartEdition instead!!!
            AfxMessageBox("Can't load a JavaVirtualMachine Version 1.3. \r\nInstall the \"Java Runtime Enviroment 1.3\" from www.javasoft.com!!",MB_ICONSTOP );
            return false;
         }
      }

      try
      {
         // Load the dedicated JavaVirtualMachine into system
         //
         JVM::load((LPCSTR)jvm);

         if(JNIEnvHelper::getEnv()==NULL)
         {
            SET_PARAMETER("JavaVirtualMachine","");
            AfxMessageBox("Can't load the selected JavaVirtualMachine. \r\nInstall the \"Java Runtime Enviroment 1.3\" from www.javasoft.com!!",MB_ICONSTOP );
            return false;
         }
      }
      catch(...)
      {
         // error during loading the JVM
         AfxMessageBox("Can't load a JavaVirtualMachine. \r\nInstall the \"Java Runtime Enviroment 1.3\" from www.javasoft.com.\r\n** Java features now disabled **",MB_ICONSTOP );
         return false;
      }
   }

   return true;
}


//----------------------------------------------------------------------------
void JavaPluginManager::registerPainter()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   // WindowsGDI-Wrapper laden und native methoden registrieren
   //
   LM::log(LM::info,"loading Windows-GDI wrapper 'Painter'");
   m_painterClass = (jclass)JNIEnvHelper::NewGlobalRef(JNIEnvHelper::FindClass("Painter"));
   JNIEnvHelper::RegisterNatives(m_painterClass, painter_methods, _countof(painter_methods));
}


//----------------------------------------------------------------------------
void JavaPluginManager::registerI18N()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   // I18N-Wrapper laden und native methoden registrieren
   //
   LM::log(LM::info,"loading application i18n wrapper 'I18N'");
   m_i18nClass = (jclass)JNIEnvHelper::NewGlobalRef(JNIEnvHelper::FindClass("I18N"));
   JNIEnvHelper::RegisterNatives(m_i18nClass, i18n_methods, _countof(i18n_methods));
}

//----------------------------------------------------------------------------
void JavaPluginManager::registerConfiguration()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   // Configuration-Wrapper laden und native methoden registrieren
   //
   LM::log(LM::info,"loading application configuration wrapper 'Configuration'");
   m_configurationClass = (jclass)JNIEnvHelper::NewGlobalRef(JNIEnvHelper::FindClass("Configuration"));
   JNIEnvHelper::RegisterNatives(m_configurationClass, configuration_methods, _countof(configuration_methods));
}


//----------------------------------------------------------------------------
void JavaPluginManager::registerTrace()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   // Trace laden und native methoden registrieren
   //
	LM::log(LM::info,"loading debug interface 'Trace'");
   m_traceClass = (jclass)JNIEnvHelper::NewGlobalRef(JNIEnvHelper::FindClass("Trace"));
   JNIEnvHelper::RegisterNatives(m_traceClass, trace_methods, _countof(trace_methods));
}


//----------------------------------------------------------------------------
void JavaPluginManager::registerPluginManager()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   // Trace laden und native methoden registrieren
   //
	LM::log(LM::info,"loading plugin helper 'PluginManager'");
   m_pluginManagerClass = (jclass)JNIEnvHelper::NewGlobalRef(JNIEnvHelper::FindClass("de/freegroup/digitalsimulator/plugin/PluginManager"));
//   if(JNIEnvHelper::ExceptionOccurred()==false)
   JNIEnvHelper::RegisterNatives(m_pluginManagerClass, plugin_methods, _countof(plugin_methods));
}

//----------------------------------------------------------------------------
void JavaPluginManager::registerObjectPlugin()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

   // Trace laden und native methoden registrieren
   //
	LM::log(LM::info,"loading native methods of 'ObjectPlugin'");
   m_objectPluginClass = (jclass)JNIEnvHelper::NewGlobalRef(JNIEnvHelper::FindClass("ObjectPlugin"));
   JNIEnvHelper::RegisterNatives(m_objectPluginClass, objectPlugin_methods, _countof(objectPlugin_methods));
}

//----------------------------------------------------------------------------
void JavaPluginManager::clear()
//----------------------------------------------------------------------------
{
	PROC_TRACE;

} 


#endif