/* NO WARRANTY
 *
 *    BECAUSE THE PROGRAM IS IN THE PUBLIC DOMAIN, THERE IS NO
 *    WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE
 *    LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE AUTHORS
 *    AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT
 *    WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *    BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 *    AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS TO
 *    THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD
 *    THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL
 *    NECESSARY SERVICING, REPAIR OR CORRECTION.
 *
 *    IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
 *    WRITING WILL ANY AUTHOR, OR ANY OTHER PARTY WHO MAY MODIFY
 *    AND/OR REDISTRIBUTE THE PROGRAM, BE LIABLE TO YOU FOR DAMAGES,
 *    INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL
 *    DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM
 *    (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING
 *    RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES
 *    OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
 *    PROGRAMS), EVEN IF SUCH AUTHOR OR OTHER PARTY HAS BEEN ADVISED
 *    OF THE POSSIBILITY OF SUCH DAMAGES.
 */

#include "stdafx.h"
#include "DragDrop.h"
#include "DragDropObject.h"
#include "DragDropText.h"
#include "DragDropDocument.h"
#include "DragDropMetafile.h"
#include "DragDropLink.h"

#include "Application\Debug\LogManager.h"

#include "Application\Dialogs\ObjectDialogs\DialogSecondaryObjectOptions.h"
#include "Application\Objects\buildin\digital\ElectricPortLink.h"
#include "Application\Objects\buildin\digital\ElectricNode.h"
#include "Application\Objects\buildin\digital\ElectricNodeContext.h"


IMPLEMENT_SERIAL(CElectricNode, DragDropArea, 1)
const  CElectricNode::m_version = 3;


//----------------------------------------------------------------------------
CElectricNode::CElectricNode(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   m_data.pOwner = this;

   m_pContext  = NULL;
}

//----------------------------------------------------------------------------
CElectricNode::~CElectricNode(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   if(m_pContext){
      // it is possible that the context has copy
      // a pointer from a strukt/class in the param buffer.
      // Give the context a chance to delete/free this pointer
      // The param pointer itself will be deleted from the
      // context.
      //
      m_pContext->CleanupParam(m_data);
   }

   // The DragDrop-children will be deleted by DragDropArea Cleanup
   //
}


//----------------------------------------------------------------------------
void CElectricNode::OnTimerStart(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   m_pContext->OnStartCalculate(m_data);
}


//----------------------------------------------------------------------------
void CElectricNode::OnTimerEnd(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   m_pContext->OnStopCalculate(m_data);
}

//----------------------------------------------------------------------------
BOOL CElectricNode::paint(CDC* pDC){
//----------------------------------------------------------------------------
	PROC_TRACE;

   // Falls der context sich nicht selber zeichnen kann
   // z.B Buildin Objekte, werden diese durch die Engine
   // gezeichnet.
   //......Plugins k�nnen sich selber zeichen und ben�tigen nicht
   // immer das generischen zeichnen.....es wreden dann keine Ports
   // gezeichnet. Dies mu� dann der Context auch selbst erledigen
   //
   if(!m_pContext->paint( m_data,pDC)){
      // generic painting from the DragDrop objects
      //
      inherited::paint(pDC);
   }

   return TRUE;
}

//----------------------------------------------------------------------------
DragDropObject* CElectricNode::Clone() const{
//----------------------------------------------------------------------------
	PROC_TRACE;

   // nicht Clone der Basisklasse aufrufen!!!! es sollen nicht die 
   // Arrayelemente mit kopiert werden
   //
   DragDropObject* pObj = DragDropObject::Clone();    
   ASSERT(pObj->IsKindOf(RUNTIME_CLASS(CElectricNode)));                  
   CElectricNode *pNode =(CElectricNode*) pObj ;

   pNode->m_bGrabChildSelection = m_bGrabChildSelection;   // from DragDropArea
   pNode->m_data.inCount        = m_data.inCount;
   pNode->m_data.outCount       = m_data.outCount ;
   pNode->m_data.param = new char[m_pContext->GetParamCount()];
   memcpy(pNode->m_data.param,m_data.param,m_pContext->GetParamCount());
   pNode->m_data.location       = GetLocation();
   pNode->m_data.metaName       = m_data.metaName;
   pNode->m_pContext            = m_pContext;
   pNode->m_pContext->Initialize(pNode->m_data);
   
   return pNode;
}


//----------------------------------------------------------------------------
CString CElectricNode::GetDescriptionText(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   return m_pContext->GetDescriptionText();
}

//----------------------------------------------------------------------------
CString CElectricNode::GetMetaName(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   return m_data.metaName;
}

//----------------------------------------------------------------------------
CString CElectricNode::GetGroup()const{
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   return m_pContext->GetGroup();
}

//----------------------------------------------------------------------------
long CElectricNode::GetContextMenuId(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   return m_pContext->GetContextMenuId();
}


//----------------------------------------------------------------------------
void CElectricNode::DoCalculate(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   m_pContext->DoCalculate(m_data);
}


//----------------------------------------------------------------------------
BOOL CElectricNode::DoLButtonDblClk(UINT nFlags, CPoint pointDP, CPoint pointLP, CClientDC* pDC, DragDropView* pView){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   m_pContext->OnLButtonDblClk(m_data);
   return TRUE;
}


//----------------------------------------------------------------------------
void CElectricNode::DoOption(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   m_pContext->onOption(m_data);
}


//----------------------------------------------------------------------------
void CElectricNode::DoExtendedOption(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   CDialogSecondaryObjectOptions d(NULL,m_data);

   if(d.DoModal()==IDOK) {
      if(d.m_metaNameString != m_data.metaName){
         m_pContext= CElectricNodeContext::GetContext(d.m_metaNameString);
         m_data.metaName = d.m_metaNameString;
         // Alten eventuell zu kleinen Speicherbereich l�schen
         //
         delete [] m_data.param;
         m_data.param = new char[m_pContext->GetParamCount()];
         memset(m_data.param,0,m_pContext->GetParamCount());
         m_pContext->InitParam(m_data);

         // initialisierung mu� sein, da sich eine Ein/Ausg�nge ver�ndert
         // haben k�nnen. Dies sind nicht vom Kontext abh�ngig d.h. selber Kontext
         // aber unterschiedeliche Anzahl von Ports m�glich
         //
         m_pContext->SetInputCount(m_data , d.m_inputCount);
         m_pContext->SetOutputCount(m_data, d.m_outputCount);
         m_pContext->Initialize(m_data);
      }
   }
}


//----------------------------------------------------------------------------
BOOL CElectricNode::DoLButtonClick(UINT nFlags, CPoint pointDP, CPoint pointLP, CClientDC* pDC, DragDropView* pView){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   m_pContext->OnLButtonClick(m_data);
   m_pContext->selectIcon(m_data);
   m_pContext->Layout(m_data);

   return TRUE;
}


//----------------------------------------------------------------------------
BOOL CElectricNode::DoLButtonUp(UINT nFlags, CPoint pointDP, CPoint pointLP, CClientDC* pDC, DragDropView* pView){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   m_pContext->OnLButtonUp(m_data);
   m_pContext->selectIcon(m_data);
   m_pContext->Layout(m_data);

   return  inherited::DoLButtonUp( nFlags, pointDP, pointLP, pDC, pView);
}


//----------------------------------------------------------------------------
BOOL CElectricNode::DoLButtonDown(UINT nFlags, CPoint pointDP, CPoint pointLP, CClientDC* pDC, DragDropView* pView){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   m_pContext->OnLButtonDown(m_data);
   m_pContext->selectIcon(m_data);
   m_pContext->Layout(m_data);

   return inherited::DoLButtonDown(nFlags, pointDP, pointLP, pDC, pView);
}

//----------------------------------------------------------------------------
void CElectricNode::SetLocation(int x, int y){
//----------------------------------------------------------------------------
	PROC_TRACE;
   
   // Das Objekt darf nicht die linke und die obere Kante 
   // �berschreiten. Es darf aber so weit recht wie m�glich
   // und so weit nach unten wie m�glich
   //
   inherited::SetLocation( max(0,x), min(0, y));
}

//----------------------------------------------------------------------------
void CElectricNode::SetBoundingRect(int nLeft, int nTop, int nRight, int nBottom){
//----------------------------------------------------------------------------
	PROC_TRACE;

   // Das Objekt darf nicht die linke und die obere Kante 
   // �berschreiten. Es darf aber so weit recht wie m�glich
   // und so weit nach unten wie m�glich
   //
   if(nLeft<0){
      nRight = nRight - nLeft;
      nLeft  = 0;
   }
   if( nTop>0){
      nBottom= nBottom - nTop;
      nTop   = 0;
   }

   inherited::SetBoundingRect(nLeft, nTop, nRight, nBottom);
}

//----------------------------------------------------------------------------
void CElectricNode::GeometryChange(CRect* pRectPrevious){
//----------------------------------------------------------------------------
	PROC_TRACE;
   
   inherited::GeometryChange(pRectPrevious);
   m_pContext->OnGeometryChange(m_data);
   m_pContext->selectIcon(m_data);
   m_data.location = m_data.icons[0]->GetLocation();
}

//----------------------------------------------------------------------------
void CElectricNode::Serialize(CArchive& ar){
//----------------------------------------------------------------------------
	PROC_TRACE;


   inherited::Serialize(ar);

   m_data.inPorts.Serialize(ar);
   m_data.outPorts.Serialize(ar);
   m_data.icons.Serialize(ar);

   static CDWordArray  param;
   param.Serialize(ar); // ist eigentlich veraltet...kann man aber leider
                        // nicht streichen, da sonst alte Dateien nicht mehr lesbar sind

   if (ar.IsStoring()) {
       // gespeichert wird nur noch Version 3
       //
       ar << m_version;
       ar << m_data.pLabel;
       ar << m_data.metaName;
       ar << m_data.location;
       ar << m_data.size;
       ar << m_pContext->GetParamCount();
       ar.Write(m_data.param,m_pContext->GetParamCount());
       ar << m_data.logicState.IsHigh();
   }
   else
   {
      int version;
      ar >> version;

      switch (version){
      case 1: // Fileformat Version 1
         {
          // altes parameterformat in das neue konvertieren
          //
          if(param.GetSize()>0){
             if(m_data.param){
                delete[] m_data.param;
                m_data.param = NULL;
             }
             m_data.param = new char[param.GetSize()];
             for(int loop=0; loop< param.GetSize();loop++){
                m_data.param[loop]= param[loop];
             }
          }
          else{
             if(m_data.param){
                delete[] m_data.param;
                m_data.param = NULL;
             }
          }
          ar >> m_data.pLabel;
          ar >> m_data.metaName;
          ar >> m_data.location;
          ar >> m_data.size;
          m_data.inCount  = m_data.inPorts.GetSize();
          m_data.outCount = m_data.outPorts.GetSize();
         }
          break;
      case 2: // Fileformat Version 2
         {
          DWORD bufferSize;
          ar >> m_data.pLabel;
          ar >> m_data.metaName;
          ar >> m_data.location;
          ar >> m_data.size;
          ar >> bufferSize;
          // neues parameterformat einlesen
          //
          if(m_data.param){
            delete []m_data.param;
            m_data.param= NULL;
          }
          if(bufferSize>0){
            m_data.param = new char[bufferSize];
            ar.Read(m_data.param,bufferSize);
          }
          m_data.inCount  = m_data.inPorts.GetSize();
          m_data.outCount = m_data.outPorts.GetSize();
         }
          break;
      case 3: // Fileformat Version 3
         {
          DWORD bufferSize;
          BOOL  b;
          ar >> m_data.pLabel;
          ar >> m_data.metaName;
          ar >> m_data.location;
          ar >> m_data.size;
          ar >> bufferSize;
          // neues parameterformat einlesen
          //
          if(m_data.param){
            delete []m_data.param;
            m_data.param= NULL;
          }
          if(bufferSize>0){
            m_data.param = new char[bufferSize];
            ar.Read(m_data.param,bufferSize);
          }
          ar >> b; m_data.logicState = b?CLogicValue::High: CLogicValue::Low;
          m_data.inCount  = m_data.inPorts.GetSize();
          m_data.outCount = m_data.outPorts.GetSize();
         }
          break;
      default:
          LM::log(LM::error,"Unknown objekt version %d during serializing of class %s found",version,GetClassName());
          break;
      }
      m_pContext = CElectricNodeContext::GetContext(m_data.metaName);
      m_pContext->Initialize(m_data);
   }
}


//----------------------------------------------------------------------------
CSize CElectricNode::GetInputCountRange(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   return m_pContext->GetInputCountRange();
}


//----------------------------------------------------------------------------
CSize CElectricNode::GetOutputCountRange(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   return m_pContext->GetOutputCountRange();
}

//----------------------------------------------------------------------------
long CElectricNode::GetInputCount(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   return m_data.inPorts.GetSize();
}


//----------------------------------------------------------------------------
long CElectricNode::GetOutputCount(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   return m_data.outPorts.GetSize();
}

//----------------------------------------------------------------------------
CElectricPort*    CElectricNode::GetInput(int index){
//----------------------------------------------------------------------------
	PROC_TRACE;

   return m_data.inPorts[index];
}

//----------------------------------------------------------------------------
CElectricPort*    CElectricNode::GetOutput(int index){
//----------------------------------------------------------------------------
	PROC_TRACE;

   return m_data.outPorts[index];
}


//----------------------------------------------------------------------------
CRect CElectricNode::GetBoundingRect(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   return m_boundingRect;
}


//----------------------------------------------------------------------------
long  CElectricNode::GetHelpId(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   assert(m_pContext != NULL);
   return m_pContext->GetHelpId();
}
