/* NO WARRANTY
 *
 *    BECAUSE THE PROGRAM IS IN THE PUBLIC DOMAIN, THERE IS NO
 *    WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE
 *    LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE AUTHORS
 *    AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT
 *    WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *    BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 *    AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS TO
 *    THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD
 *    THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL
 *    NECESSARY SERVICING, REPAIR OR CORRECTION.
 *
 *    IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
 *    WRITING WILL ANY AUTHOR, OR ANY OTHER PARTY WHO MAY MODIFY
 *    AND/OR REDISTRIBUTE THE PROGRAM, BE LIABLE TO YOU FOR DAMAGES,
 *    INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL
 *    DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM
 *    (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING
 *    RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES
 *    OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
 *    PROGRAMS), EVEN IF SUCH AUTHOR OR OTHER PARTY HAS BEEN ADVISED
 *    OF THE POSSIBILITY OF SUCH DAMAGES.
 */

#include <math.h>
#include "stdafx.h"
#include "Application\DigitalSimulatorApp.h"
#include "LogoClientWindow.h"


BEGIN_MESSAGE_MAP(CLogoClientWindow, CWnd)
//{{AFX_MSG_MAP(CLogoClientWindow)
ON_WM_ERASEBKGND()
ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


IMPLEMENT_DYNCREATE(CLogoClientWindow, CWnd)

//----------------------------------------------------------------------------
CLogoClientWindow::CLogoClientWindow(){
//----------------------------------------------------------------------------
	PROC_TRACE;

}

//----------------------------------------------------------------------------
CLogoClientWindow::~CLogoClientWindow(){
//----------------------------------------------------------------------------
	PROC_TRACE;

}


//----------------------------------------------------------------------------
BOOL CLogoClientWindow::OnEraseBkgnd(CDC* pDC) {
//----------------------------------------------------------------------------
	PROC_TRACE;


   return inherited::OnEraseBkgnd(pDC);
}



//----------------------------------------------------------------------------
void CLogoClientWindow::OnPaint(){
//----------------------------------------------------------------------------
	PROC_TRACE;


   inherited::OnPaint();
   /*
   Invalidate();
  
   CPaintDC dc(this); // device context for painting
   CRect rect;
   GetClientRect(rect);
	int nWidth  = rect.Width(); 
	int nHeight = rect.Height();
	CRect rectangle;
   
   int rgbStart = 210;
   int rgbEnd   = 190;

   int div = rgbStart- rgbEnd;

	for(int i = 0; i < nWidth; ++i) // Fill in strip
	{
		rectangle.SetRect(i, 0, i+1, nHeight);
      int r=rgbStart - MulDiv(div,i, nHeight);
		dc.FillSolidRect(&rectangle, RGB(r, r, r+12));
	}
   */
}

