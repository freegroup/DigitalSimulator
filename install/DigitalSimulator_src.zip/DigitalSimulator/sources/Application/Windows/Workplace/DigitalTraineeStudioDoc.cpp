/* NO WARRANTY
 *
 *    BECAUSE THE PROGRAM IS IN THE PUBLIC DOMAIN, THERE IS NO
 *    WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE
 *    LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE AUTHORS
 *    AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT
 *    WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *    BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 *    AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS TO
 *    THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD
 *    THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL
 *    NECESSARY SERVICING, REPAIR OR CORRECTION.
 *
 *    IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
 *    WRITING WILL ANY AUTHOR, OR ANY OTHER PARTY WHO MAY MODIFY
 *    AND/OR REDISTRIBUTE THE PROGRAM, BE LIABLE TO YOU FOR DAMAGES,
 *    INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL
 *    DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM
 *    (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING
 *    RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES
 *    OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
 *    PROGRAMS), EVEN IF SUCH AUTHOR OR OTHER PARTY HAS BEEN ADVISED
 *    OF THE POSSIBILITY OF SUCH DAMAGES.
 */

#include "stdafx.h"

#include "Application\DigitalSimulatorApp.h"
#include "Application\i18n\ResourceTranslater.h"
#include "Application\Windows\Oszi\OsziView.h"

#include "DigitalTraineeStudioView.h"
#include "DigitalTraineeStudioDoc.h"

/////////////////////////////////////////////////////////////////////////////
// CDigitalTraineeStudioDoc

IMPLEMENT_DYNCREATE(CDigitalTraineeStudioDoc, DragDropDocument)
//----------------------------------------------------------------------------
CDigitalTraineeStudioDoc::CDigitalTraineeStudioDoc(){
//----------------------------------------------------------------------------
	PROC_TRACE;

}

//----------------------------------------------------------------------------
CDigitalTraineeStudioDoc::~CDigitalTraineeStudioDoc(){
//----------------------------------------------------------------------------
	PROC_TRACE;

}

//----------------------------------------------------------------------------
BOOL CDigitalTraineeStudioDoc::OnNewDocument(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   if (!inherited::OnNewDocument())
		return FALSE;

   SetMinSize (CSize(21*m_nUnit/4,28*m_nUnit/4));   // half of the default size in default minimum
   SetDocumentSize (CSize(2*21*m_nUnit,2*28*m_nUnit));       // 2* (21 cm X 27) cm (sort of 8.5 x 11)

	return TRUE;
}


//----------------------------------------------------------------------------
void CDigitalTraineeStudioDoc::Serialize(CArchive& ar){
//----------------------------------------------------------------------------
	PROC_TRACE;

   // Alle Objecte Einlesen....eventuell sind auch ein
   // paar ViewPoint darunter. Dise muessen dann `von Hand` mit
   // dem OsziView verbunden werden
   //
   inherited::Serialize(ar);

   if (ar.IsLoading()){
      // den ersten View finden ....und den einzigsten
      //
      POSITION pos = GetFirstViewPosition();
      if(pos != NULL){
         CView* pView = GetNextView(pos);
         if(pView && pView->IsKindOf(RUNTIME_CLASS(CDigitalTraineeStudioView))) {
            CDigitalTraineeStudioView *dragDropView = (CDigitalTraineeStudioView *)pView;

            // Alle OsziStrokes finden
            //
            POSITION objPos = GetFirstObjectPos();
            while(objPos!= NULL){
               DragDropObject* obj = (DragDropObject*)GetNextObject( objPos );
               if(obj->IsKindOf(RUNTIME_CLASS(CElectricPortLink))){
                  CElectricPortLink* link = (CElectricPortLink*)obj;
                  COsziStroke*       stroke = link->GetOsziStroke();
                  if(stroke !=NULL){
                     dragDropView->m_osziView->Add(stroke);
                  }
               }
            }
         }
      }   
   }
}


//----------------------------------------------------------------------------
BOOL CDigitalTraineeStudioDoc::SaveModified(){
//----------------------------------------------------------------------------
	PROC_TRACE;

	if (!IsModified())
		return TRUE;        // ok to continue

	// get name/title of document
	CString name;
	if (m_strPathName.IsEmpty())	{
		// get name based on caption
		name = m_strTitle;
		if (name.IsEmpty())
			name = TRANSLATE("Unbekannt");
	}
	else	{
		// get name based on file title of path name
		name = m_strPathName;
	}


	char  prompt[1000];
	sprintf(prompt, TRANSLATE("�nderungen in %s speichern?"), name);
	switch (AfxMessageBox(prompt, MB_YESNOCANCEL, AFX_IDP_ASK_TO_SAVE))
	{
	case IDCANCEL:
		return FALSE;       // don't continue

	case IDYES:
		// If so, either Save or Update, as appropriate
		if (!DoFileSave())
			return FALSE;       // don't continue
		break;

	case IDNO:
		// If not saving changes, revert the document
		break;

	default:
		ASSERT(FALSE);
		break;
	}
	return TRUE;    // keep going
}
