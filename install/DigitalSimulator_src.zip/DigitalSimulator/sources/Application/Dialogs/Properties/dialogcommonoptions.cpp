/* NO WARRANTY
 *
 *    BECAUSE THE PROGRAM IS IN THE PUBLIC DOMAIN, THERE IS NO
 *    WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE
 *    LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE AUTHORS
 *    AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT
 *    WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *    BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 *    AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS TO
 *    THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD
 *    THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL
 *    NECESSARY SERVICING, REPAIR OR CORRECTION.
 *
 *    IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
 *    WRITING WILL ANY AUTHOR, OR ANY OTHER PARTY WHO MAY MODIFY
 *    AND/OR REDISTRIBUTE THE PROGRAM, BE LIABLE TO YOU FOR DAMAGES,
 *    INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL
 *    DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM
 *    (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING
 *    RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES
 *    OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
 *    PROGRAMS), EVEN IF SUCH AUTHOR OR OTHER PARTY HAS BEEN ADVISED
 *    OF THE POSSIBILITY OF SUCH DAMAGES.
 */

#include "stdafx.h"
#include <stdio.h>
#include <io.h>

#include "Application\DigitalSimulatorApp.h"
#include "Application\i18n\ResourceTranslater.h"
#include "Application\Configuration\ParameterManager.h"

#include "DialogCommonOptions.h"




BEGIN_MESSAGE_MAP(CDialogCommonOptions, CSnapDialog)
	//{{AFX_MSG_MAP(CDialogCommonOptions)
	ON_CBN_SELCHANGE(IDC_LANGUAGE_COMBO, OnSelchangeLanguageCombo)
	ON_BN_CLICKED(IDC_USE_IT, OnUseIt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//----------------------------------------------------------------------------
CDialogCommonOptions::CDialogCommonOptions(CWnd* pParent /*=NULL*/)
: inherited(CDialogCommonOptions::IDD, pParent){
//----------------------------------------------------------------------------
	PROC_TRACE;

	//{{AFX_DATA_INIT(CDialogCommonOptions)
	//}}AFX_DATA_INIT
   m_languageNotifyee.setListener(this);
}

//----------------------------------------------------------------------------
CDialogCommonOptions:: ~CDialogCommonOptions(){
//----------------------------------------------------------------------------
	PROC_TRACE;

}

//----------------------------------------------------------------------------
void CDialogCommonOptions::DoDataExchange(CDataExchange* pDX){
//----------------------------------------------------------------------------
	PROC_TRACE;

	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogCommonOptions)
	DDX_Control(pDX, IDC_LINE_STATIC, m_lineImage);
	DDX_Control(pDX, IDC_CROSS_STATIC, m_crossImage);
	DDX_Control(pDX, IDC_DOT_STATIC, m_dotImage);
	DDX_Control(pDX, IDC_USE_IT, m_useitButton);
	DDX_Control(pDX, IDCANCEL, m_cancelButton);
	DDX_Control(pDX, IDOK, m_okButton);
	DDX_Control(pDX, IDC_FLAG_ANIMATION, m_flagAnimation);
	DDX_Control(pDX, IDC_GRID_X_EDIT, m_xEdit);
	DDX_Control(pDX, IDC_GRID_Y_EDIT, m_yEdit);
	DDX_Control(pDX, IDC_Y_SPIN, m_ySpin);
	DDX_Control(pDX, IDC_X_SPIN, m_xSpin);
	DDX_Control(pDX, IDC_LANGUAGE_COMBO, m_languageCombo);
	//}}AFX_DATA_MAP
}


/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CDialogCommonOptions 


//----------------------------------------------------------------------------
void CDialogCommonOptions::TranslateGUI(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   SET_ITEM_TEXT(IDC_LANGUAGE_STATIC,"Sprache");
   SET_ITEM_TEXT(IDOK,"Ok");
   SET_ITEM_TEXT(IDCANCEL,"Abbruch");
   SET_ITEM_TEXT(IDC_GRID_X_STATIC,"Breite");
   SET_ITEM_TEXT(IDC_GRID_Y_STATIC,"H�he");
   SET_ITEM_TEXT(IDC_USE_IT,"�bernehmen");
   SetWindowText(TRANSLATE("Allgemeine Einstellungen"));
   
   SetFlagAnimation(GET_PARAMETER("Language"));
}


//----------------------------------------------------------------------------
BOOL CDialogCommonOptions::OnInitDialog(){
//----------------------------------------------------------------------------
	PROC_TRACE;

	inherited::OnInitDialog();
	
   m_okButton.SetShaded();
   m_cancelButton.SetShaded();
   m_useitButton.SetShaded();

   m_xSpin.SetBuddy(&m_xEdit);
	m_xSpin.SetRange(50, 200.);
	m_xSpin.SetPos(min(200,max(50,atoi(GET_PARAMETER("GridX")))));
	m_xSpin.SetDelta(10);

	m_ySpin.SetBuddy(&m_yEdit);
	m_ySpin.SetRange(50, 200.);
	m_ySpin.SetPos(min(200,max(50,atoi(GET_PARAMETER("GridY")))));
	m_ySpin.SetDelta(10);

   CString style = GET_PARAMETER("GridStyle");
   if( style == "Dot"){
      ((CButton*)GetDlgItem(IDC_DOT_RADIO))->SetCheck(1);
   }
   else if(style == "Cross" ){
      ((CButton*)GetDlgItem(IDC_CROSS_RADIO))->SetCheck(1);
   }
   else {
      ((CButton*)GetDlgItem(IDC_LINE_RADIO))->SetCheck(1);
   }

   TranslateGUI();

   fillLanguageCombo();

   return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

//----------------------------------------------------------------------------
void CDialogCommonOptions::fillLanguageCombo(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   struct _finddata_t c_file;
   CString langPath=GET_PARAMETER("LanguagePath");

   char drive[_MAX_DRIVE];
   char dir[_MAX_DIR];
   char fname[_MAX_FNAME];
   char ext[_MAX_EXT];
   long hFile;
 
   m_languageCombo.ResetContent();
   /* Find first .gop file in current directory */
   if( (hFile = _findfirst((langPath+"*.lang"), &c_file )) == -1L )
   {
	   CString msg = CString("No language file found in [")+ langPath+"*.lang" + "]";
      AfxMessageBox(msg);
   }
   else
   {
      _splitpath( c_file.name, drive, dir, fname, ext );
      m_languageCombo.AddString( fname);

      /* Find the rest of the files */
      while( _findnext( hFile, &c_file ) == 0 )
      {
         _splitpath( c_file.name, drive, dir, fname, ext );
		   m_languageCombo.AddString( fname);
      }

      _findclose( hFile );
   }
   if(CB_ERR==m_languageCombo.SelectString( 0, GET_PARAMETER("Language"))){
      m_languageCombo.SetCurSel(0);
   }

   OnSelchangeLanguageCombo();
}


//----------------------------------------------------------------------------
void CDialogCommonOptions::OnOK() {
//----------------------------------------------------------------------------
	PROC_TRACE;

	// TODO: Zus�tzliche Pr�fung hier einf�gen
   CString  lang;
	CString x;
	CString y;
	x.Format("%d", (int)m_xSpin.GetPos());
	y.Format("%d", (int)m_ySpin.GetPos());

   m_languageCombo.GetLBText(m_languageCombo.GetCurSel(),lang);
	SET_PARAMETER("Language", (LPCSTR)lang);
   SET_PARAMETER("GridX"   , (LPCSTR)x);
   SET_PARAMETER("GridY"   , (LPCSTR)y);
   if(1 == ((CButton*)GetDlgItem(IDC_DOT_RADIO))->GetState()){
      SET_PARAMETER("GridStyle" , "Dot");
   }
   else if(1 == ((CButton*)GetDlgItem(IDC_CROSS_RADIO))->GetState()){
      SET_PARAMETER("GridStyle" , "Cross");
   }
   else {
      SET_PARAMETER("GridStyle" , "Line");
   }

	inherited::OnOK();
}

//----------------------------------------------------------------------------
void CDialogCommonOptions::OnSelchangeLanguageCombo() {
//----------------------------------------------------------------------------
	PROC_TRACE;

	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
   CString lang;

   m_languageCombo.GetLBText(m_languageCombo.GetCurSel(),lang);
   SetFlagAnimation((LPCSTR)lang);

}

//----------------------------------------------------------------------------
void CDialogCommonOptions::SetFlagAnimation(CString lang) {
//----------------------------------------------------------------------------
	PROC_TRACE;


   CString flagPath = GET_PARAMETER("BannerPath");
   CString flag;

   flag = flagPath + lang +".avi";

   m_flagAnimation.Open(flag);
   m_flagAnimation.Play(0,-1,-1);
}


//----------------------------------------------------------------------------
void CDialogCommonOptions::OnUseIt(){
//----------------------------------------------------------------------------
	PROC_TRACE;

   CString lang;
	CString x;
	CString y;
	x.Format("%d", (int)m_xSpin.GetPos());
	y.Format("%d", (int)m_ySpin.GetPos());

   m_languageCombo.GetLBText(m_languageCombo.GetCurSel(),lang);
	SET_PARAMETER("Language", (LPCSTR)lang);
   SET_PARAMETER("GridX"   , (LPCSTR)x);
   SET_PARAMETER("GridY"   , (LPCSTR)y);
   if(1 == ((CButton*)GetDlgItem(IDC_DOT_RADIO))->GetState()){
      SET_PARAMETER("GridStyle" , "Dot");
   }
   else if(1 == ((CButton*)GetDlgItem(IDC_CROSS_RADIO))->GetState()){
      SET_PARAMETER("GridStyle" , "Cross");
   }
   else {
      SET_PARAMETER("GridStyle" , "Line");
   }
}
